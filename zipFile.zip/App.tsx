
import React, { useState, useEffect, useCallback } from 'react';
import { Screen, UserProfile, Lesson, Course } from './types';
import { onAuthStateChanged, auth, db, doc, getDoc, collection, getDocs } from './lib/firebase';
import { ALL_COURSES } from './constants';
import LoginScreen from './screens/LoginScreen';
import HomeScreen from './screens/HomeScreen';
import InstructorScreen from './screens/InstructorScreen';
import CourseDetailScreen from './screens/CourseDetailScreen';
import ProfileScreen from './screens/ProfileScreen';
import AdminScreen from './screens/AdminScreen';
import UpcomingScreen from './screens/UpcomingScreen';
import CompletedCoursesScreen from './screens/CompletedCoursesScreen';

const App: React.FC = () => {
  const [currentScreen, setCurrentScreen] = useState<Screen>('LOGIN');
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [lastVideo, setLastVideo] = useState<Lesson | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCourse, setSelectedCourse] = useState<Course>(ALL_COURSES[0]);
  const [uploadedLessons, setUploadedLessons] = useState<Lesson[]>([]);

  const fetchUploads = useCallback(async () => {
    try {
      const q = collection(db, "uploads");
      const snapshot = await getDocs(q);
      const lessons = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Lesson[];
      setUploadedLessons(lessons);
    } catch (e) {
      console.error("Error fetching uploads:", e);
    }
  }, []);

  useEffect(() => {
    fetchUploads();
  }, [fetchUploads]);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      if (user) {
        const userDoc = await getDoc(doc(db, "users", user.uid));
        if (userDoc.exists()) {
          setCurrentUser(userDoc.data() as UserProfile);
        }
        if (currentScreen === 'LOGIN') {
          if (user.email === 'forfarzivada@gmail.com') setCurrentScreen('ADMIN');
          else setCurrentScreen('HOME');
        }
      } else {
        setCurrentUser(null);
        setCurrentScreen('LOGIN');
      }
    });
    return () => unsubscribe();
  }, [currentScreen]);

  const navigateToCourse = (courseId: string) => {
    const course = ALL_COURSES.find(c => c.id === courseId) || ALL_COURSES[0];
    setSelectedCourse(course);
    setCurrentScreen('COURSE');
  };

  const renderScreen = () => {
    switch (currentScreen) {
      case 'LOGIN':
        return <LoginScreen onNavigate={setCurrentScreen} />;
      case 'HOME':
        return <HomeScreen user={currentUser} onNavigate={setCurrentScreen} onSelectCourse={navigateToCourse} lastVideo={lastVideo} searchQuery={searchQuery} setSearchQuery={setSearchQuery} />;
      case 'INSTRUCTORS':
        return <InstructorScreen onNavigate={setCurrentScreen} onSelectCourse={navigateToCourse} />;
      case 'COURSE':
        return <CourseDetailScreen 
          onNavigate={setCurrentScreen} 
          setLastVideo={setLastVideo} 
          user={currentUser} 
          setUser={setCurrentUser} 
          course={selectedCourse} 
          extraLessons={uploadedLessons} 
          onRefresh={fetchUploads}
        />;
      case 'PROFILE':
        return <ProfileScreen onNavigate={setCurrentScreen} user={currentUser} />;
      case 'ADMIN':
        return <AdminScreen onNavigate={setCurrentScreen} onRefresh={fetchUploads} />;
      case 'UPCOMING':
        return <UpcomingScreen onNavigate={setCurrentScreen} />;
      case 'COMPLETED_COURSES':
        return <CompletedCoursesScreen onNavigate={setCurrentScreen} user={currentUser} onSelectCourse={navigateToCourse} />;
      default:
        return <LoginScreen onNavigate={setCurrentScreen} />;
    }
  };

  return (
    <div className="flex justify-center min-h-screen bg-slate-950 md:py-8">
      <div className="w-full max-w-[430px] h-full min-h-screen md:min-h-[884px] md:h-[884px] bg-background-dark relative overflow-hidden md:rounded-[50px] md:shadow-2xl flex flex-col border border-white/5">
        {renderScreen()}
      </div>
    </div>
  );
};

export default App;
